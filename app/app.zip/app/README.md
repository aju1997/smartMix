# smartMix

Companion app to smartMix hardware. 

## Getting Started

This project is a starting point for a Flutter application.

Make sure you have Flutter sdk installed

Before running project run the command
"flutter packages get"
